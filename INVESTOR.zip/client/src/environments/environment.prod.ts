export const environment = {
  production: true,
  API_URL: 'http://localhost:3000/',
  
};
