import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {



AddForm: FormGroup |any; submitted = false; btnsubmitted = false;
  constructor(private dialogRef: MatDialogRef<RegisterComponent>,private fb: FormBuilder,public apiService :ApiService) { 

  }
  type:boolean=false;
  cptype:boolean=false;
  get f() { return this.AddForm.controls; }

  ngOnInit(): void {
    this.AddForm = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
  })
  
  }
 
  onSubmit(){
    this.submitted=true;
    this.AddForm.get('name').markAsTouched();
    this.AddForm.get('email').markAsTouched();
    this.AddForm.get('password').markAsTouched();
    if(this.AddForm.invalid){
      return;
    }else{
      this.apiService.post('teacher_login',this.AddForm.value).subscribe((data:any) => {
    
      })
    }
  }
  closeLoginModel(): void {
  this.dialogRef.close();
}
  }
