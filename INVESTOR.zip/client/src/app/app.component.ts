import { Component } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ApiService } from './api.service';
import { Socket } from 'ngx-socket-io';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'client';
  stocks:any=[]
  user:any
  flag:number=0
constructor(private socket:Socket,private dialog: MatDialog,public apiservice:ApiService) {
  // this.openLoginModel()
  var json:any=sessionStorage.getItem('users')
this.user=(JSON.parse(json))
if(this.user){
  this.flag=1
}else{
  this.flag=0
}
console.log();

 }
ngOnInit(): void {

    this.apiservice.receiveMessage1().subscribe((stocs: any=[]) => {
 
      this.stocks=stocs
    });

  }
  openLoginModel(): void {
  const dialogConfig: MatDialogConfig = {
    width: '400px', // Adjust the width as per your requirement
    position: {
      top: '0',
    },
  };

  const dialogRef = this.dialog.open(LoginComponent,  {position: {top: '0%', left: '20%'}});

  dialogRef.afterClosed().subscribe((result: any) => {
    // Handle the result when the login model component is closed
    console.log('Login model component closed');
  });
}

openregisterModel(): void {
  const dialogConfig: MatDialogConfig = {
    width: '400px', // Adjust the width as per your requirement
       panelClass: 'top-dialog',

  };

  const dialogRef = this.dialog.open(RegisterComponent,  {position: {top: '10%', left: '20%'}});

  dialogRef.afterClosed().subscribe((result: any) => {
    // Handle the result when the register model component is closed
    console.log('Register model component closed');
  });
}
// openLoginModel(): void {
//   const dialogRef = this.dialog.open(LoginComponent, {
//     width: '400px', 
//      position: {
//       top: '0',
//     },// Adjust the width as per your requirement
//   });

//   dialogRef.afterClosed().subscribe((result:any) => {
//     // Handle the result when the login model component is closed
//     console.log('Login model component closed');
//   });
// }
// openregisterModel(): void {
//   const dialogRef = this.dialog.open(RegisterComponent, {
//     width: '400px', 
//      position: {
//       top: '0',
//     },// Adjust the width as per your requirement
//   });

//   dialogRef.afterClosed().subscribe((result:any) => {
//     // Handle the result when the login model component is closed
//     console.log('Login model component closed');
//   });
// }
logout(){
  console.log("hellooo");
  
  sessionStorage.removeItem('users')
    this.flag=0

}
}
