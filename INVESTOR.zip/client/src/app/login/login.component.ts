import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { RegisterComponent } from '../register/register.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {


AddForm: FormGroup |any; submitted = false; btnsubmitted = false;
  constructor(private router:Router,private dialogRef: MatDialogRef<LoginComponent>,private dialog: MatDialog,private fb: FormBuilder,public apiService :ApiService) { 

  }
  type:boolean=false;
  cptype:boolean=false;
  get f() { return this.AddForm.controls; }

  ngOnInit(): void {
    this.AddForm = this.fb.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
  })
  }
  onSubmit(){
    this.submitted=true;
    this.AddForm.get('email').markAsTouched();
    this.AddForm.get('password').markAsTouched();
    console.log(this.AddForm.value);
    
    if(this.AddForm.invalid){
      return;
    }else{
      this.apiService.post('login',this.AddForm.value).subscribe((data:any) => {
        console.log(data,'this is login data');
        sessionStorage.setItem('users',JSON.stringify(data.user))   

window.location.reload()
        this.closeLoginModel()

      })
    }
  }
openregisterModel(): void {
  const dialogRef = this.dialog.open(RegisterComponent, {
    // width: '400px', // Adjust the width as per your requirement
  });
this.closeLoginModel()
  dialogRef.afterClosed().subscribe((result:any) => {
    // Handle the result when the login model component is closed
    console.log('Login model component closed');
  });
}
closeLoginModel(): void {
  this.dialogRef.close();
}
}
