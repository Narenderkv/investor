import { Component } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Socket } from 'ngx-socket-io';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  stocks:any=[]
  user:any
  flag:any
  constructor(private socket:Socket,private dialog: MatDialog,public apiservice:ApiService) {
  }
ngOnInit(): void {
  var json:any=sessionStorage.getItem('users')
this.user=(JSON.parse(json))
if(this.user){
  this.flag=1
}else{
  this.flag=0
}
    this.apiservice.receiveMessage1().subscribe((stocs: any=[]) => {
 
      this.stocks=stocs
    });

  }
    onMark(tutorObject:any){
    var sendRequestData: any = {};
    console.log('tutorObject>>>>>>>>',tutorObject);
    if(tutorObject.favourite == 0){
      sendRequestData.type = 1;
    }else{
      sendRequestData.type = 0;
    }
    // return;
    
        sendRequestData.user_id  = this.user.id;
        sendRequestData.teacher_id = tutorObject.id;
        // sendRequestData.type = 1;
        console.log('sendRequestData',sendRequestData)
        // return;
        this.apiservice.post('mark_favourite', sendRequestData).subscribe((data: any) => {
          if (data.replyCode == "success") {
            
          } else {
            
          }
        })
  }
}
