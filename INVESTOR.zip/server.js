const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const { Sequelize, DataTypes } = require('sequelize');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: 'http://localhost:4200',
    credentials: true,
  },
});

app.use(express.static('public'));
app.use(bodyParser.json());
app.use(cors({ origin: 'http://localhost:4200', credentials: true }));

// Set up Sequelize
const sequelize = new Sequelize('invester', 'root', 'root', {
  host: 'localhost',
  dialect: 'mysql',
});

// Define the Stock model
const Stock = sequelize.define('Stock', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  company_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  stock_value: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
});
const Wishlist = sequelize.define('Wishlist', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  stockId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});
const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: false,
  },

  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

// Sync the model with the database
sequelize
  .sync({ alter: true }) // Add the alter option to modify the table schema
  .then(() => {
    console.log('Database connection has been established successfully.');
  })
  .catch((error) => {
    console.error('Unable to connect to the database:', error);
  });


setInterval(async () => {
  try {
    const stocks = await Stock.findAll();
    stocks.forEach(async (stock) => {
      const newStockValue = Math.random() * 100; // Generate a random stock value
      stock.stock_value = newStockValue;
      await stock.save();

      Stock.findAll({
        order: [['stock_value', 'DESC']],
        limit: 20
      }).then((stocks) => {
        io.emit('stockUpdate', stocks); // Emit the fetched stocks data to the connected client
      })
        .catch((error) => {
          console.error('Error retrieving stocks:', error);
          // Handle the error if necessary
        });

      Wishlist.findAll({
        where: { userId: req.user.id }, // Access the logged-in user ID from req.user
        include: [Stock],
      }).then((stocks) => {
        io.emit('wishlist', stocks); // Emit the fetched stocks data to the connected client
      })
        .catch((error) => {
          console.error('Error retrieving stocks:', error);
          // Handle the error if necessary
        });

      // const userWishlist = await Wishlist.findAll({
      //   where: { userId: req.user.id }, // Access the logged-in user ID from req.user
      //   include: [Stock],
      // });

    });
  } catch (error) {
    console.error('Error generating stock prices:', error);
  }
}, 4000);

app.post('/signup', async (req, res) => {
  try {
    const { email, name, password } = req.body;
    const newUser = await User.create({ email, name, password });
    res.status(201).json({ message: 'User created successfully', user: newUser });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ message: 'Failed to create user' });
  }
});

// Login route
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) {
      res.status(404).json({ message: 'User not found' });
      return;
    }
    if (user.password != password) {
      res.status(401).json({ message: 'Invalid password' });
      return;
    }
    res.status(200).json({ message: 'Login successful', user });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Failed to login' });
  }
});
// Start the server
const port = 3000;
server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
